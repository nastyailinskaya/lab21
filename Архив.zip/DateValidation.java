import java.util.Scanner;
import java.util.regex.*;

public class DateValidation {

    public static void main(String[] args) {
        // ввод строки
        Scanner scanner = new Scanner(System.in);
        System.out.println("Дата: ");
        String date = scanner.nextLine();
        // валидируем формат даты dd/mm/yyyy
        if (Pattern.compile("\\d{2}/\\d{2}/\\d{4}").matcher(date).matches()) {
            // валидируем саму дату
            int day = Integer.parseInt(date.substring(0, 2));
            int month = Integer.parseInt(date.substring(3, 5));
            int year = Integer.parseInt(date.substring(6));
            boolean isDate = year >= 1900; // проверяем год
            // проверяем соответствие день-месяц
            switch (month) {
                // месяцы, в которых 31 день
                case 1, 3, 5, 7, 8, 10, 12 -> isDate &= day <= 31;
                // месяцы, в которых 30 дней
                case 4, 6, 9, 11 -> isDate &= day <= 30;
                // февраль: проверяем год на високосность
                // високосный год делится на 4 и не делится на 100, либо делится на 400
                case 2 -> isDate &= (day <= 28 || ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) && day <= 29);
                // другой номер месяца невозможен
                default -> isDate = false;
            }
            if (isDate) {
                System.out.println("Введенное выражение является датой");
            }
            else {
                System.out.println("Введенное выражение не является датой");
            }
        }
        else {
            System.out.println("Введенное выражение не соответствует заданному формату даты dd/mm/yyyy");
        }
    }
}
