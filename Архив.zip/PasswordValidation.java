import java.util.Scanner;
import java.util.regex.Pattern;

public class PasswordValidation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // цикл пока не получим надежный пароль
        while (true){
            // ввод строки
            System.out.print("Пароль: ");
            String password = scanner.nextLine();
            // проверяем пароль
            // ^(?=.*[A-Z]) - хотя бы одна заглавная буква
            // (?=.*[a-z]) - хотя бы одна маленькая
            // (?=.*\d) - хотя бы одна цифра
            // [_A-Za-z\d] - состоит из знака подчеркивания, английских букв и цифр
            // {8,} - минимум 8 символов
            if (Pattern.compile("^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)[_A-Za-z\\d]{8,}$").matcher(password).matches()) {
                System.out.println("Пароль надежен");
                break;
            } else {
                System.out.println("Пароль ненадежен. Повторите ввод");
            }
        }
    }
}
